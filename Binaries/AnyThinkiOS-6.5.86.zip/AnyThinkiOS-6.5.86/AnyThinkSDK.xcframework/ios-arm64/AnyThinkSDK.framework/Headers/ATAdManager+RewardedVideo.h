//
//  ATAdManager+RewardedVideo.h
//  AnyThinkSDK
//
//  Created by Martin Lau on 05/07/2018.
//  Copyright © 2018 Martin Lau. All rights reserved.
//

#import <AnyThinkSDK/ATAdManager.h>
#import <AnyThinkSDK/ATRewardedVideoDelegate.h>
#import <AnyThinkSDK/ATCheckLoadModel.h>
#import <AnyThinkSDK/ATAPI.h>
#import <AnyThinkSDK/ATNativeMixRewardedVideoView.h>

NS_ASSUME_NONNULL_BEGIN

typedef void(^NativeMixRewardedAdViewBlock)(ATNativeMixRewardedVideoView *mixRewardedVideoView);


/*
 * Third-party extra data
 */
extern NSString *const kATAdLoadingExtraKeywordKey;
extern NSString *const kATAdLoadingExtraUserDataKeywordKey;
extern NSString *const kATAdLoadingExtraUserIDKey;
extern NSString *const kATAdLoadingExtraLocationKey;
extern NSString *const kATAdLoadingExtraRewardNameKey;
extern NSString *const kATAdLoadingExtraRewardAmountKey;

// Klevin SDK
extern NSString *const kATRewardedVideoKlevinRewardTimeKey;
extern NSString *const kATRewardedVideoKlevinRewardTriggerKey;


@interface ATAdManager (RewardedVideo)

/// Display this ad slot rewarded video ad
/// @param placementID - TopOn's ad placement id
/// @param viewController  - display ad window
/// @param delegate - delegate object
- (void)showRewardedVideoWithPlacementID:(NSString *)placementID
                        inViewController:(nullable UIViewController *)viewController
                                delegate:(id<ATRewardedVideoDelegate>)delegate;

- (void)showRewardedVideoWithPlacementID:(NSString *)placementID
                                  config:(ATShowConfig *)config
                        inViewController:(nullable UIViewController *)viewController
                                delegate:(id<ATRewardedVideoDelegate>)delegate;

/// Display this ad slot rewarded video ad
/// @param placementID - TopOn's ad placement id
/// @param scene - the scene id
/// @param viewController  - display ad window, If nil, the top view controller will be used.
/// @param delegate - delegate object
- (void)showRewardedVideoWithPlacementID:(NSString *)placementID
                                   scene:(NSString *)scene
                        inViewController:(nullable UIViewController *)viewController
                                delegate:(id<ATRewardedVideoDelegate>)delegate;

- (void)showRewardedVideoWithPlacementID:(NSString *)placementID
                                  config:(ATShowConfig *)config
                        inViewController:(nullable UIViewController *)viewController
                                delegate:(id<ATRewardedVideoDelegate>)delegate
                                nativeMixViewBlock:(nullable NativeMixRewardedAdViewBlock)nativeMixViewBlock;


/// check whether the rewardedVideo ad is ready
/// v5.7.06+
- (BOOL)rewardedVideoReadyForPlacementID:(NSString *)placementID;

/// Get the status object of the current ad slot ATCheckLoadModel
- (nullable ATCheckLoadModel *)checkRewardedVideoLoadStatusForPlacementID:(NSString *)placementID;

/// Query all cached information of the ad slot
- (nullable NSArray<NSDictionary *> *)getRewardedVideoValidAdsForPlacementID:(NSString *)placementID;

/// Enter the current ad slot cache status statistics in the business scenario.
/// @param scene - ad Scenario
/// v5.7.91+
- (void)entryRewardedVideoScenarioWithPlacementID:(NSString *)placementID
                                            scene:(NSString *)scene;

@end

NS_ASSUME_NONNULL_END
